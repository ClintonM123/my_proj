function showAlert() {
    alert("Hello from Flask!");
}